from .fitting import *

__doc__ = fitting.__doc__
